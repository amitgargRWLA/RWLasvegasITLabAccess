namespace RWLasvegasITLabAccess.ViewModels
{
    public class SignoffRecord
    {
        public string Id { get; set; }
    }
}